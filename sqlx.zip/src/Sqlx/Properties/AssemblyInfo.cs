using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Sqlx.Tests")]

