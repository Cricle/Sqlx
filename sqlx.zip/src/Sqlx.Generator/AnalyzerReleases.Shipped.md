; Shipped analyzer releases

## 1.0.0

### New Rules

| Rule ID | Category | Severity | Notes |
|---------|----------|----------|-------|
| SQLX001 | Design   | Warning  | Id property should be first public property for ordinal access optimization |
