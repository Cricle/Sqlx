using System.Runtime.CompilerServices;

// Allow test project to access internal types
[assembly: InternalsVisibleTo("Sqlx.Tests")]
